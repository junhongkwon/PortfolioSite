let resetID = document.querySelector('#resetId');
let resultID = document.querySelector('#resultId');
let num1 = document.querySelector('#enterNumber1');
let num2 = document.querySelector('#enterNumber2');
let num3 = document.querySelector('#enterNumber3');
let num4 = document.querySelector('#enterNumber4');
let num5 = document.querySelector('#enterNumber5');
let num6 = document.querySelector('#enterNumber6');
let numArray=[];
let myNumberText = document.querySelector('#myNumberText');
resetID.addEventListener('click', function(){
    num1.value='';
    num2.value='';
    num3.value='';
    num4.value='';
    num5.value='';
    num6.value='';
    myNumberText.value='';
    lottoResult.textContent='';
    location.reload(true);
})


var hubo = Array(45).fill().map(function(element, index){
    return index+1;
});

var lottoResult = document.querySelector('#lottoResult');
console.log(hubo);
var shuffle=[];
while(hubo.length>0){
    var goValue = hubo.splice(Math.floor(Math.random()*hubo.length),1)[0];
    shuffle.push(goValue); 
}

console.log(shuffle);
var bonus = shuffle[shuffle.length-1];
var lottoNumber = shuffle.slice(0,6).sort(function(p, c){
    return p-c;
});

console.log('lottoNumber->', lottoNumber, 'bonus->', bonus);
var result = document.querySelector('#result'); 

resultID.addEventListener('click', function(){
    numArray.push(num1.value, num2.value, num3.value, num4.value, num5.value, num6.value);   
    let count=0;
    console.log(numArray, lottoNumber);

    for(var i=0; i<lottoNumber.length; i++)
       {
          if(lottoNumber.indexOf(Number(numArray[i]))>-1){
             count=count+1;
             }
       }  
       if (count===6){
           lottoResult.textContent="1등입니다!";
       }
       else if(count===5 && numArray.includes(String(bonus))){
           lottoResult.textContent="2등입니다!"
       }
       else if(count===5){
           lottoResult.textContent="3등입니다!"
       }
       else if(count===4){
           lottoResult.textContent="4등입니다!"
       }
       else if(count===3){
           lottoResult.textContent="5등입니다!"
       }
       else{
           lottoResult.textContent="꽝입니다!"
       }
   
   console.log(count);
      
       myNumberText.value=numArray;
});


function ballPainting(number, result){
    var ball = document.createElement('div');
    
    ball.textContent = number;
    if(number>=1 && number<=10){
        ball.style.backgroundColor='red';
    }
    else if(number>=11 && number<=20){
        ball.style.backgroundColor='orange';
    }
    else if(number>=21 && number<=30){
        ball.style.backgroundColor='yellow';
    }
    else if(number>=31 && number<=40){
        ball.style.backgroundColor='blue';
    }
    else{
        ball.style.backgroundColor='green';
    }
    ball.style.display='inline-block';
    ball.style.border='1px solid black';
    ball.style.borderRadius='30px';
    ball.style.width='45px';
    ball.style.height='45px';
    ball.style.textAlign='center';
    ball.style.marginRight='10px';
    ball.style.fontSize='28px';

    
    result.appendChild(ball);
}
// NumberPainting();
for(let i=0; i<=5; i++){
    setTimeout(function asyCallBack(){
        ballPainting(lottoNumber[i], result)
    },1000*i + 1000);
}

setTimeout(function asyCallBack(){
    var bonusSquare = document.querySelector('.bonus');
    ballPainting(bonus, bonusSquare);
},7000);

function buttonUpSize(button){
    button.style.fontSize="15px";
}

function buttonCurrentSize(button){
    button.style.fontSize="13.3px";
}
// function NumberPainting(){
// setTimeout(function asyCallBack(){
//     ballPainting(lottoNumber[0], result)
// },1000);
// setTimeout(function asyCallBack(){   
//     ballPainting(lottoNumber[1], result)    
// },2000);
// setTimeout(function asyCallBack(){  
//     ballPainting(lottoNumber[2], result)    
// },3000);
// setTimeout(function asyCallBack(){ 
//     ballPainting(lottoNumber[3], result)   
// },4000);
// setTimeout(function asyCallBack(){
//     ballPainting(lottoNumber[4], result)     
// },5000);
// setTimeout(function asyCallBack(){
//     ballPainting(lottoNumber[5], result)     
// },6000);
    

// }
